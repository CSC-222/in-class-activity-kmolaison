package CSC_Racers;

import java.util.Objects;

public class HandleCar extends Car {

    public HandleCar() {

        this.UpdateCoordinates(0,0);
        this.UpdateVelocity(0,0);
        this.setMaxSpeed(5);
        this.setIdNumber("3");
        this.SetWinner(false);
    }

    public void Move(Racetrack track)
    {
        int row = 0;
        int col = 0;
        int lowWeight = 9999;
        boolean pathClear = true;

        int rowIncrease = 0;
        int colIncrease = 0;

        if (this.getRowVelocity() < this.getMaxSpeed())
        {
            rowIncrease = 1;
        }
        if (this.getColVelocity() < this.getMaxSpeed())
        {
            colIncrease = 1;
        }

        boolean nearFinish = CheckFinish(track);

        for(int i = -(this.getRowVelocity() + rowIncrease); i <= this.getRowVelocity() + rowIncrease; i++)
        {
            for(int j = -(this.getColVelocity() + colIncrease); j <= this.getColVelocity() + colIncrease;  j++)
            {
                //Ensure only moves within the track are checked
                if(this.getRow() + i > 0 && this.getCol() + j > 0 && this.getRow() + i < track.Height()-1 && this.getCol() + j < track.Width()-1 )
                {
                    pathClear = this.isPathClear(track, this.getRow() + i, this.getCol() + j);
                }
                if(this.getRow() + i > 0 && this.getCol() + j > 0 && this.getRow() + i < track.Height()-1 && this.getCol() + j < track.Width()-1 )
                {
                    int reducer = 0;
                    if(nearFinish && track.GetWeight(this.getRow() + i,this.getCol() + j) >= track.getMaxWeight() - getMaxSpeed())
                    {
                        //System.out.println("Weight: " + track.GetWeight(this.getRow() + i,this.getCol() + j));
                        //lowWeight = track.GetWeight(this.getRow() + i,this.getCol() + j) - track.getMaxWeight() - 1;
                        reducer = track.getMaxWeight() + 1;
                        //System.out.println("Weight After Change: " + (track.GetWeight(this.getRow() + i,this.getCol() + j) - track.getMaxWeight() - 1));
                    }
                    if(lowWeight > track.GetWeight(this.getRow() + i,this.getCol() + j) - reducer && pathClear && !Objects.equals(track.GetTrack(this.getRow() + i, this.getCol() + j), "1") && !Objects.equals(track.GetTrack(this.getRow() + i, this.getCol() + j), "3") && !Objects.equals(track.GetTrack(this.getRow() + i, this.getCol() + j), "2"))
                    {
                        lowWeight = track.GetWeight(this.getRow() + i,this.getCol() + j) - reducer;
                        row = i;
                        col = j;
                        System.out.println("Coordinates: " + row + "   " + col);
                    }
                }
            }
        }
        pathClear = this.isPathClear(track, this.getRow() + row,this.getCol() + col);
        if(pathClear)
        {
            this.UpdateCarInfo(track, row, col);
        }
    }

}
